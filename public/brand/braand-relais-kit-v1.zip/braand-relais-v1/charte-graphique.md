# Braand Relais - Charte graphique et design system

Version 1.0.0 - 30 octobre 2026

## 1. Braand

Relais · Charte graphique et design system

Une identité pour confier un objectif, faire avancer le travail et retrouver un résultat exploitable.

Édition 1.0.0 · 30 octobre 2026

## 2. Le guide de référence

Identité, interface et transmission

Ce dossier réunit les règles d’identité Relais et le système d’interface effectivement présent dans Braand. La marque évolue ; la navigation, les fonctionnalités, la facturation et les autorisations restent celles du produit.

[Illustration : contents ; voir le PDF/HTML et les fichiers du kit.]

- Pages 3–7 : positionnement, signe, mot-symbole et déclinaisons.
- Pages 8–12 : couleurs, thèmes, typographie et géométrie.
- Pages 13–22 : composants, comportements, accessibilité et langage.
- Pages 23–24 : fichiers, intégration et maintenance.

Les valeurs des CSS livrés et les relevés calculés font autorité pour l’interface. Les exemples du catalogue sont fictifs et ne représentent ni une opération fournisseur ni un état de compte réel.

## 3. La personnalité de Braand

Une présence utile, précise et chaleureuse

Braand est une plateforme d’agents IA pour déléguer du travail : recherche, création, documents, analyse, logiciel, organisation et opérations, ainsi que marketing et ventes. Le chat est le point d’entrée ; les outils, livrables et décisions prolongent la conversation.

| Principe | Expression concrète |
| --- | --- |
| Clarté | Une action principale identifiable ; des libellés qui décrivent le prochain geste. |
| Continuité | Une même identité dans le chat, les paramètres, les fichiers et les documents. |
| Maîtrise | Des budgets et validations visibles au moment où ils sont nécessaires. |
| Honnêteté | Un brouillon, une vérification et une action exécutée portent des statuts distincts. |
| Chaleur | Formes douces, langage respectueux et absence de jargon inutile. |

La marque ne promet pas une autonomie illimitée. Les messages décrivent les capacités disponibles et le travail réellement confirmé.

## 4. Le signe Relais

Deux formes, une seule signature

[Illustration : symbol ; voir le PDF/HTML et les fichiers du kit.]

Le symbole associe deux formes pleines asymétriques. L’espace entre elles fait partie du dessin : il évoque un passage et une coopération, sans devenir une flèche littérale.

- Conserver les deux tracés, leur espacement et leurs proportions.
- Utiliser les versions vectorielles pour toute mise à l’échelle.
- Employer le symbole seul dans les emplacements compacts : rail, application et favicon.
- Le logo est statique. L’activité de l’agent est portée par les statuts réels et le compagnon du chat.

Source géométrique : brand/relais.geometry.json. Les SVG, le composant React et les exports PNG partagent ce même dessin.

## 5. Le logo complet

Le symbole et le mot-symbole forment un ensemble

[Illustration : lockup ; voir le PDF/HTML et les fichiers du kit.]

Le nom s’écrit « Braand » dans les textes. Le mot-symbole graphique est dessiné en minuscules : « braand ». Ses lettres sont des tracés vectoriels ; il ne se recompose pas en tapant le nom avec une autre police.

| Élément | Règle |
| --- | --- |
| Composition | Symbole à gauche, mot-symbole à droite, alignement optique conservé. |
| Couleurs | Signe bleu et lettres encre sur fond clair ; signe bleu et lettres blanches sur fond sombre. |
| Zone de protection | Ajouter autour du logo une marge minimale égale au quart de la hauteur visible du symbole. |
| Exceptions | Le favicon et l’icône d’application disposent de leur propre composition adaptée au carré. |

L’espace transparent du fichier ne remplace pas à lui seul la zone de protection. Ajouter la marge dans la mise en page.

## 6. Déclinaisons et petites tailles

Une silhouette constante sur tous les supports

[Illustration : versions ; voir le PDF/HTML et les fichiers du kit.]

| Usage | Version conseillée |
| --- | --- |
| Navigation ouverte | Logo complet, hauteur de composition 28 px. |
| Pages légales et aide | Logo complet, hauteur de composition 32 px. |
| Navigation réduite et petits emplacements | Symbole seul dans un contrôle accessible. |
| Favicon | Fichier dédié ; vérifier à 16 px, préférer 24 px et plus quand l’espace le permet. |
| Application / raccourci mobile | Icône carrée dédiée, exports 180, 192 et 512 px. |
| Impression et partenaires | SVG monochrome noir ou blanc selon le fond. |

En impression, conserver au moins 6 mm de hauteur pour le symbole seul et 24 mm de largeur pour le logo complet, puis contrôler un tirage réel selon le procédé.

## 7. Protection de l’identité

La forme reste reconnaissable avant les effets

[Illustration : protection ; voir le PDF/HTML et les fichiers du kit.]

- Ne pas étirer, comprimer, incliner ou réordonner les formes.
- Ne pas fermer ou réduire le passage central au point de fusionner les deux parties.
- Ne pas ajouter de contour, ombre portée, lueur, dégradé ou relief aux fichiers officiels.
- Ne pas mélanger le signe Relais avec l’ancien astérisque.
- Ne pas intégrer un symbole de concurrent dans le logo ou le mot-symbole.
- Sur une image chargée, réserver une zone calme ou employer un fond uni de la palette.

Le compagnon animé de Bot Avatars reste un élément conversationnel distinct. Il ne remplace pas le logo dans une facture, un document de marque ou un favicon.

## 8. La palette de marque

Un bleu de reconnaissance, une base neutre

[Illustration : brand-palette ; voir le PDF/HTML et les fichiers du kit.]

| Couleur | Valeur | Rôle |
| --- | --- | --- |
| Bleu Relais | #4B93FF | Signe et identité de communication. |
| Encre | #181819 | Texte de marque et fond sombre de référence. |
| Blanc | #FFFFFF | Fond clair, texte inversé et monochrome. |
| Bleu action | #1793FF | Action principale de l’interface sombre, avec texte noir. |

Le bleu de marque et le bleu d’action ont des rôles différents. Une interface reste majoritairement neutre ; la couleur sert à reconnaître, orienter et signaler.

Dans l’application, le signe suit la couleur d’accent choisie par la personne. Les exports de communication gardent le bleu Relais officiel. Les versions monochromes sont des déclinaisons autorisées.

## 9. Le thème sombre

Couleurs sémantiques de référence

[Illustration : dark-palette ; voir le PDF/HTML et les fichiers du kit.]

Les couches utilisent des tons opaques ou du blanc translucide. Un token alpha se compose sur sa véritable surface ; sa valeur isolée ne constitue pas un fond de page.

[Illustration : dark-tokens ; voir le PDF/HTML et les fichiers du kit.]

Les valeurs de référence sont extraites de app/design-tokens.css. appearance.css peut remplacer les rôles d’accent, d’action, de lien et de message utilisateur selon les préférences.

## 10. Le thème clair et les accents

La même hiérarchie, adaptée à la lumière

[Illustration : light-palette ; voir le PDF/HTML et les fichiers du kit.]

[Illustration : light-tokens ; voir le PDF/HTML et les fichiers du kit.]

Modes disponibles : clair, sombre et système. La préférence s’applique avant le premier rendu et se partage entre les onglets du même appareil.

Les palettes existantes couvrent les choix par défaut, bleu, bleu ciel, violet, rose, orange, vert, brun et monochrome. Utiliser les valeurs de lib/appearance.ts ; ne pas inventer une nouvelle couleur dans un composant.

La couleur seule ne porte jamais le statut : ajouter un texte, une coche, une icône ou un état de contrôle. Les documents ouverts conservent leurs couleurs d’origine.

## 11. La typographie

Manrope pour l’interface, tracés pour le logo

[Illustration : typography ; voir le PDF/HTML et les fichiers du kit.]

| Usage | Échelle observée | Graisse |
| --- | --- | --- |
| Texte courant de l’application | 14 px / 21 px | 400 |
| Texte de conversation | 16 px / 22 px | 400 |
| Libellé d’action | 13 px / 20 px | 600 |
| Texte secondaire | 12 px / 20 px | 400 |
| Titre de fenêtre | 18 px / 26 px | 600 |
| Titre d’état vide | 24 px / 30 px | 600 |

La police variable Manrope est auto-hébergée, avec font-display: swap et une pile de repli système. Les interfaces existantes emploient aussi des tailles contextuelles pour les grands titres, les données et les petits indicateurs.

Manrope est distribuée sous SIL Open Font License 1.1. Le dossier Polices contient le fichier et la licence. Aucun fichier de police propriétaire d’un concurrent n’est inclus.

## 12. Géométrie et mise en page

Un rythme commun, des zones qui gardent leur contexte

[Illustration : layout ; voir le PDF/HTML et les fichiers du kit.]

| Repère | Valeur de référence |
| --- | --- |
| Unité de base | 4 px |
| Sidebar / rail | 240 px / 72 px |
| Largeur de lecture | 768 px |
| Panneau de travail initial | 360 px ; redimensionnable selon l’espace disponible |
| Paramètres | 880 × 680 px au maximum ; navigation interne 224 px |
| Rayons | 12 px, 16 px, 22 px, 32 px ; actions en pilule selon le composant |
| Seuil mobile principal | 767 px ; autres seuils contextuels dans les CSS fournis |

Conserver les alignements et les groupes fonctionnels. Le contenu défile dans sa zone ; une navigation ou une fenêtre ne doit pas effacer un brouillon. Les interfaces compactes affichent une zone principale à la fois.

## 13. Actions et boutons

Une priorité visible, un retour immédiat

[Illustration : buttons ; voir le PDF/HTML et les fichiers du kit.]

| Variante | Quand l’utiliser |
| --- | --- |
| Principale | Le prochain geste le plus important de la zone. |
| Secondaire | Une alternative ou une action de consultation. |
| Discrète / ghost | Retour, annulation, action contextuelle peu fréquente. |
| Destructive | Suppression ou retrait : libellé explicite, confirmation selon l’impact. |
| Icône seule | Action familière, nom accessible et cible suffisante. |

Base .button : hauteur minimale 36 px, padding 8 × 16 px, texte 13/20 et rayon pilule. Les composants UI génériques possèdent leurs tailles propres ; sur mobile, prévoir des cibles effectives d’au moins 44 × 44 px.

Prévoir repos, survol, focus, pressé, désactivé et attente. Pendant une écriture, bloquer les doubles clics et conserver un retour lisible. Un bouton désactivé ne remplace pas l’explication de son indisponibilité.

## 14. Champs et choix

Les informations nécessaires au bon moment

[Illustration : forms ; voir le PDF/HTML et les fichiers du kit.]

- Un libellé persistant pour chaque champ ; le placeholder complète le libellé.
- Une erreur à proximité du champ, reliée avec aria-describedby ; aria-invalid si pertinent.
- Choix exclusifs : radios ou contrôle équivalent accessible. Choix multiples : cases à cocher.
- Ne pas préremplir un budget, une destination ou un consentement de manière à inventer un accord.
- Préserver la saisie en cas d’erreur, de fermeture prévue ou de navigation interne.
- Une recherche précise son périmètre et peut distinguer une absence de résultat d’un service indisponible.

Les exemples ci-dessus illustrent les états visuels. Ils ne créent aucune connexion, dépense ou inscription réelle.

## 15. Navigation et contexte

Des destinations stables, un historique maîtrisé

[Illustration : navigation ; voir le PDF/HTML et les fichiers du kit.]

L’architecture déployée conserve Chat, Missions, Studio, Campagnes et Tableau de bord. L’identité Relais n’ajoute ni une nouvelle Bibliothèque ni une réorganisation des rubriques par elle-même.

- Afficher la rubrique active par le fond et le libellé, sans dépendre uniquement de la couleur.
- Le rail conserve des noms accessibles et un bouton pour déployer la navigation.
- Les discussions disposent de leurs états épinglé, non lu et archivé, sans duplication.
- Sur mobile, tiroir et voile gardent une sortie explicite ; le focus revient au contrôle déclencheur.
- Paramètres et compte restent des surfaces superposées qui préservent le contexte conversationnel.

Les propositions de navigation montrées en atelier sont des pistes distinctes. Elles ne sont pas présentées ici comme des fonctionnalités déjà livrées.

## 16. Le chat et le compositeur

Une intelligence cohérente, une interface discrète

[Illustration : chat ; voir le PDF/HTML et les fichiers du kit.]

| Élément | Comportement |
| --- | --- |
| Compositeur desktop | 58 px au repos ; le texte grandit en hauteur, puis les actions passent sous le texte. |
| Texte long | Zone de texte jusqu’à 192 px, puis défilement interne ; largeur stable. |
| Mobile | Actions sous le texte ; cibles tactiles confortables. |
| Attente | Compagnon actif et bouton d’arrêt ; pas de bandeau technique sous le champ. |
| Réponse | Markdown stable, liens contrôlés et ressources réelles au fil des événements. |
| Interruption | Conserver la réponse partielle et le brouillon ; ne pas simuler une livraison réussie. |

Le compagnon fait 64 px à l’accueil et 32 px près d’une réponse. Seule la réponse en cours utilise son état animé ; la réduction du mouvement est respectée.

## 17. Cartes, fichiers et statuts

Le contenu et son état avant la décoration

[Illustration : resources ; voir le PDF/HTML et les fichiers du kit.]

- Une carte rassemble un titre, une information utile et une action claire. Éviter les résumés identiques répétés.
- Fichiers : nom, type et taille ; téléchargement authentifié pour les données privées.
- Ne pas recolorer le contenu d’un PDF ou d’un document fourni par l’utilisateur.
- Un résultat disponible apparaît dès qu’il est confirmé ; dédupliquer les reçus répétés.
- Les états brouillon, à valider, en cours, prêt, en pause, incertain et échec ont des sens distincts.

Le bleu ne certifie pas un succès. Un badge « Prêt » n’est utilisé qu’avec une ressource réelle ; un état fournisseur incertain exige une vérification, pas une relance aveugle.

## 18. Fenêtres, menus et paramètres

Des surfaces temporaires avec une sortie claire

[Illustration : dialog ; voir le PDF/HTML et les fichiers du kit.]

| Surface | Règles |
| --- | --- |
| Dialogue | Titre explicite, fermeture identifiable, focus contenu et rendu au déclencheur. |
| Menu | Actions courtes, clavier, focus visible et choix en cours signalé. |
| Paramètres | Navigation et contenu défilent sans couper les actions ; onglet actif accessible. |
| Sous-parcours | Une confirmation sensible protège une action précise ; ne pas empiler inutilement les fenêtres. |
| Connexion | Formulaire e-mail intégré ; confirmation de lien à usage unique ; aucun mot de passe ajouté. |

Les rubriques existantes couvrent Général, Connecteurs, Compétences, Portefeuille, Facturation, Équipe et budgets, Stockage, Autorisations, Aide et informations légales. Certaines fonctions restent conditionnées aux droits et à la configuration.

## 19. Accessibilité

La lisibilité est une condition du système

[Illustration : contrast ; voir le PDF/HTML et les fichiers du kit.]

- Contraste visé : au moins 4,5:1 pour les textes courants ; 3:1 pour les grands textes et les limites visuelles nécessaires.
- Focus visible : contour de 2 px, décalage de 3 px dans l’application.
- Chaque contrôle possède un nom ; les icônes décoratives sont masquées aux lecteurs d’écran.
- Conserver les éléments sémantiques natifs et un ordre de tabulation logique.
- Tester au clavier, à 200 % de zoom et sur petit écran ; les chiffres et les erreurs restent lisibles.
- Pour les graphiques, proposer des libellés, données ou contrôles accessibles au clavier.

Les ratios affichés sont calculés sur les couleurs effectives du thème par défaut et leur fond. Ils ne constituent pas une certification de conformité de l’ensemble du SaaS ni de toutes les palettes personnalisées.

## 20. Mouvement et fluidité

Une animation utile, courte et facultative

| Rôle | Référence |
| --- | --- |
| Transition courante | 150 ms |
| Courbe | cubic-bezier(.2,.75,.25,1) |
| Navigation et panneau | Conserver le contexte ; ne pas attendre une animation pour répondre. |
| Réduction du mouvement | Supprimer les mouvements non essentiels, y compris le suivi du pointeur du compagnon. |
| Flux de texte | Mettre à jour les blocs utiles, limiter les sauts de mise en page et préserver les résultats partiels. |
| Logo | Statique ; aucun rebond, rotation permanente ou progression fictive. |

Ne pas annoncer une durée ou un pourcentage inventé. Un état visuel doit provenir d’un événement réel : recherche, outil, création, vérification, validation attendue, résultat ou erreur.

Les bibliothèques, lecteurs et vues lourdes sont chargés progressivement lorsque le produit le permet. Aucune métrique de performance ne doit être présentée sans mesure et scénario identifiables.

## 21. Voix et messages

Dire le résultat, le blocage et le prochain geste

| Préférer | Éviter |
| --- | --- |
| « Le fichier est prêt. Télécharger le CSV. » | « Mission accomplie » sans fichier vérifiable. |
| « Cette connexion a expiré. Reconnecter le compte. » | Une erreur technique brute ou un silence. |
| « Brouillon enregistré. Publication en attente de votre accord. » | Présenter le brouillon comme déjà publié. |
| « La réponse a été interrompue. Le texte reçu est conservé. » | Effacer le contenu partiel ou afficher un succès. |
| « Renseignez la destination pour continuer. » | Un message vague qui oblige à deviner le champ manquant. |

Style : français simple dans l’interface actuelle, tutoiement ou vouvoiement cohérent dans une même surface. Dans une conversation, suivre la langue et les références de la personne, en préservant noms, monnaies et unités.

Les liens légaux s’ouvrent dans un nouvel onglet avec une indication explicite. Les détails de fournisseurs restent dans les endroits où ils aident à comprendre un accès, un coût ou une décision.

## 22. Catalogue et sources

Un système décrit par ses composants réels

[Illustration : component-index ; voir le PDF/HTML et les fichiers du kit.]

Le kit fournit les CSS de référence, les primitives React existantes, les tokens JSON calculés et les composants de marque. Le catalogue hors ligne illustre les primitives ; les parcours métier restent dans le dépôt du SaaS.

Les sources métier, identifiants, comptes connectés et secrets ne sont pas inclus. Les avatars et les logos de plateformes tierces restent soumis à leurs propres licences et ne font pas partie des fichiers de marque Relais.

## 23. Intégration

Des tracés partagés entre le produit et les exports

```tsx
import { BrandLogo, BrandMark } from "@/components/brand";

<BrandLogo height={28} />
<BrandMark size={24} />
```

- BrandLogo contient le nom accessible « Braand » et les tracés du mot-symbole.
- BrandMark est décoratif : le bouton ou le lien qui le contient porte son nom accessible.
- Les couleurs dans l’application proviennent de --ds-accent et --ds-text.
- Les SVG de communication utilisent la palette fixe officielle.
- L’identifiant technique historique data-design-system="muse" est conservé pour compatibilité des CSS ; il ne constitue pas l’identité de marque affichée.

Le script build-brand-assets.mjs régénère les SVG et le module de tracés depuis le fichier géométrique. Les chemins du paquet reproduisent ceux du dépôt pour faciliter l’intégration.

## 24. Livraison et maintenance

Versionner la marque, vérifier le résultat

[Illustration : delivery ; voir le PDF/HTML et les fichiers du kit.]

- Le PDF est le guide de lecture. Le HTML est une version hors ligne, avec un catalogue de composants consultable.
- Le dossier Logos contient les SVG, PNG transparents, icônes d’application et favicon.
- Les tokens et CSS sont des sources éditables ; les fontes incluent leur licence.
- Le manifeste du kit associe à chaque fichier une taille et une empreinte SHA-256.
- Toute nouvelle variante doit préserver les tracés, la lisibilité et la hiérarchie du système.
- Une évolution du produit exige de remettre à jour le guide, le catalogue et les vérifications visuelles.

Version 1.0.0 · 30 octobre 2026. Relais a été retenu par le propriétaire de Braand à partir de la planche d’exploration créée dans cette conversation. Les fichiers distribués sont des déclinaisons vectorielles et raster de cette direction.